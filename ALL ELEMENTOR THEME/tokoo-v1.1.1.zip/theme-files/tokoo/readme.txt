Tokoo
==============================
Tokoo is an answer for new trends in full resolution designs. Clean, smart, robust and flexible WordPress theme – ideal for any type of eCommerce Shop. This theme is brought to you by the same team that developed Techmarket, Electro, MediaCenter, Pizzaro and MyBag.

It features deep integration with WooCommerce core plus several of the most popular extensions:

King Composer
Visual Composer (not included with the theme)
Slider Revolution
Elementor

The codebase of Tokoo is lean and extensible which will allow develoepers to easily add functionality to your site via child theme and/or custom plugin(s).

Tokoo Documentation
==============================
You can view detailed Tokoo documentation on the Tokoo documentation web site.

Tokoo help & support
==============================
MadrasThemes customers can get support at the Madras Themes support portal.