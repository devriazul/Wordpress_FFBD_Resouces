<?php
/**
 * Template tags used in header v1
 */