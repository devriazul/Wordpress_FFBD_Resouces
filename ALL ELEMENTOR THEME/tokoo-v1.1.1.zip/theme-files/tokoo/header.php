<?php
/**
 * Header for our theme
 */

$header_version = tokoo_get_header_version();

get_header( $header_version ); ?>