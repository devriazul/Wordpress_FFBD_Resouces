<?php
/**
 * Upsells template
 */

woocommerce_upsell_display();
