<?php
/**
 * Product title template
 */

woocommerce_template_single_title();
