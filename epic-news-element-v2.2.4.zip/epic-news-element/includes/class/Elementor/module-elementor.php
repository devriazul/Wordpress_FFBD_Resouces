<?php

class EPIC_Block_1_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_2_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_3_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_4_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_5_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_6_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_7_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_8_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_9_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_10_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_11_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_12_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_13_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_14_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_15_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_16_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_17_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_18_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_19_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_20_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_21_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_22_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_23_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_24_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_25_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_26_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_27_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_28_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_29_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_30_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_31_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_32_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_33_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_34_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_35_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_36_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_37_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Block_38_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_1_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_2_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_3_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_4_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_5_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_6_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_7_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_8_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_9_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_10_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_11_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_12_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_13_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_14_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Hero_Skew_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_1_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_2_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_3_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_4_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_5_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_6_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_7_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_8_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Slider_Overlay_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Header_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Ads_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Blocklink_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Newsticker_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Videoplaylist_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Embedplaylist_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Iconlink_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Carousel_1_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Carousel_2_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Carousel_3_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Footer_Menu_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Footer_Social_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Footer_Instagram_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Footer_Header_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Review_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Push_Notification_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Element_Post_Package_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Title_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Subtitle_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Breadcrumb_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Meta_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Feature_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Content_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Share_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Tag_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Author_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Sequence_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Comment_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Post_Related_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Title_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Desc_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Breadcrumb_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Hero_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Block_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}

class EPIC_Archive_Pagination_Elementor extends \EPIC\Elementor\ModuleElementorAbstract {}
