<?php

/********* BLOCK *********/

class EPIC_Block_1_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_2_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_3_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_4_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_5_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_6_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_7_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_8_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_9_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_10_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_11_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_12_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_13_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_14_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_15_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_16_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_17_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_18_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_19_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_20_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_21_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_22_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_23_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_24_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_25_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_26_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_27_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_28_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_29_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_30_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_31_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_32_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_33_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_34_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_35_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_36_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_37_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Block_38_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

/********* HERO *********/

class EPIC_Hero_1_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_2_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_3_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_4_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_5_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_6_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_7_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_8_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_9_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_10_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_11_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_12_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_13_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_14_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Hero_Skew_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

/********* CAROUSEL *********/

class EPIC_Carousel_1_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Carousel_2_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Carousel_3_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

/********* ELEMENT *********/

class EPIC_Element_Ads_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Element_Newsticker_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Element_Header_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Element_Embedplaylist_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Element_Blocklink_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Element_Iconlink_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

/********* SLIDER *********/

class EPIC_Slider_1_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_2_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_3_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_4_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_5_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_6_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_7_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}

class EPIC_Slider_8_Widget extends \EPIC\Widget\Module\WidgetModuleAbstract {

}
