<?php

return array(

    array(
        'name'      => 'EPIC_Block_1',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_2',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_3',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_4',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_5',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_6',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_7',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_8',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_9',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_10',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_11',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_12',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_13',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_14',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_15',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_16',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_17',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_18',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_19',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_20',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_21',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_22',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_23',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_24',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_25',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_26',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_27',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_28',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_29',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_30',
        'type'      => 'block',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Block_31',
        'type'      => 'block',
        'widget'    => true
    ),
	array(
		'name'      => 'EPIC_Block_32',
		'type'      => 'block',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Block_33',
		'type'      => 'block',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Block_34',
		'type'      => 'block',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Block_35',
		'type'      => 'block',
		'widget'    => true
	),
    array(
        'name'      => 'EPIC_Block_36',
        'type'      => 'block',
        'widget'    => true
    ),
	array(
		'name'      => 'EPIC_Block_37',
		'type'      => 'block',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Block_38',
		'type'      => 'block',
		'widget'    => true
	),
    array(
        'name'      => 'EPIC_Hero_1',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_2',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_3',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_4',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_5',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_6',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_7',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_8',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_9',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_10',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_11',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_12',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_13',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_14',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Hero_Skew',
        'type'      => 'hero',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Carousel_1',
        'type'      => 'carousel',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Carousel_2',
        'type'      => 'carousel',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Carousel_3',
        'type'      => 'carousel',
        'widget'    => true
    ),


    array(
        'name'      => 'EPIC_Element_Ads',
        'type'      => 'ads',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Element_Newsticker',
        'type'      => 'newsticker',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Element_Header',
        'type'      => 'header',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Element_Embedplaylist',
        'type'      => 'video_playlist',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Element_Blocklink',
        'type'      => 'block_link',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Element_Iconlink',
        'type'      => 'icon_link',
        'widget'    => true
    ),

    array(
        'name'      => 'EPIC_Slider_1',
        'type'      => 'slider',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Slider_2',
        'type'      => 'slider',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Slider_3',
        'type'      => 'slider',
        'widget'    => true
    ),
    array(
        'name'      => 'EPIC_Slider_4',
        'type'      => 'slider',
        'widget'    => true
    ),
	array(
		'name'      => 'EPIC_Slider_5',
		'type'      => 'slider',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Slider_6',
		'type'      => 'slider',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Slider_7',
		'type'      => 'slider',
		'widget'    => true
	),
	array(
		'name'      => 'EPIC_Slider_8',
		'type'      => 'slider',
		'widget'    => true
	),

	/** Single Archive */
	array(
		'name'      => 'EPIC_Archive_Title',
		'type'      => 'archive',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Archive_Desc',
		'type'      => 'archive',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Archive_Breadcrumb',
		'type'      => 'archive',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Archive_Hero',
		'type'      => 'archive',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Archive_Block',
		'type'      => 'archive',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Archive_Pagination',
		'type'      => 'archive',
		'widget'    => false
	),

	/** Single Post */
	array(
		'name'      => 'EPIC_Post_Title',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Tag',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Sequence',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Related',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Meta',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Feature',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Content',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Comment',
		'type'      => 'post',
		'widget'    => false
	),
	array(
		'name'      => 'EPIC_Post_Author',
		'type'      => 'post',
		'widget'    => false
	),
);
