<?php
/**
 * @author : Jegtheme
 */
namespace EPIC\Module\Carousel;

Class Carousel_1_Option extends CarouselOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('EPIC - Carousel 1', 'epic-ne');
    }
}
