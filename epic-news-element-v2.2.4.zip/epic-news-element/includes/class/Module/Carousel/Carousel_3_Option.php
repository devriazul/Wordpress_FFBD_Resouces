<?php
/**
 * @author : Jegtheme
 */
namespace EPIC\Module\Carousel;

Class Carousel_3_Option extends CarouselOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('EPIC - Carousel 3', 'epic-ne');
    }
}
