<?php
/**
 * @author : Jegtheme
 */
namespace EPIC\Module\Carousel;

Class Carousel_2_Option extends CarouselOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('EPIC - Carousel 2', 'epic-ne');
    }
}
