<?php

class EPIC_Block_1 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_2 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_3 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_4 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_5 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_6 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_7 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_8 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_9 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_10 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_11 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_12 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_13 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_14 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_15 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_16 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_17 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_18 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_19 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_20 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_21 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_22 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_23 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_24 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_25 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_26 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_27 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_28 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_29 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_30 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_31 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_32 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_33 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_34 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_35 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_36 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_37 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Block_38 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_1 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_2 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_3 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_4 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_5 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_6 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_7 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Slider_8 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_1 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_2 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_3 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_4 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_5 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_6 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_7 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_8 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_9 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_10 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_11 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_12 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_13 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_14 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Hero_Skew extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Ads extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Newsticker extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Header extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Videoplaylist extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Embedplaylist extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Element_Blocklink extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Carousel_1 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Carousel_2 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}

class EPIC_Carousel_3 extends \EPIC\Gutenberg\ModuleGutenbergAbstract {}
